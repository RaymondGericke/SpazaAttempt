import 'package:casha/casha_app.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(CashaApp());
}
